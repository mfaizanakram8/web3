import React from 'react';
import './aco.css';
import Navbar from '../../Components/Navbar';
import Sidebar from '../../Components/SlideBar/indexx';
import PaymentHeader from '../../Components/Backbutton';
import { useNavigate } from 'react-router-dom';

const AccommodationPreferences = () => {
    const navigate = useNavigate();

    const handleBack = () => {
        navigate(-1);
    };

    const accommodations = [
        { id: 1, image: '/assets/t-1.png', title: 'Tree House' },
        { id: 2, image: '/assets/t-2.png', title: 'Tree House' },
        { id: 3, image: '/assets/t-3.png', title: 'Tree House' },
        { id: 4, image: '/assets/t-1.png', title: 'Tree House' },
        { id: 5, image: '/assets/t-2.png', title: 'Tree House' },
        { id: 6, image: '/assets/t-3.png', title: 'Tree House' },
        { id: 7, image: '/assets/t-1.png', title: 'Tree House' },
        { id: 8, image: '/assets/t-2.png', title: 'Tree House' },
        { id: 9, image: '/assets/t-3.png', title: 'Tree House' },
    ];

    return (
        <div className="accommodation-preferences-container">
            <Navbar />
            <div className="preferences-content">
                <Sidebar />
                <div className="preferences-main">
                    <button className="back-button">
                        <PaymentHeader onClick={handleBack} />
                    </button>
                    <h2>Accommodation Preferences</h2>
                    <p>What are your travel plans?</p>
                    <p className="unlock-text">Unlock accommodation you love.</p>
                    <div className="accommodation-grid">
                        {accommodations.map((accommodation) => (
                            <div className="accommodation-card" key={accommodation.id}>
                                <img src={accommodation.image} alt={accommodation.title} />
                                <p>{accommodation.title}</p>
                            </div>
                        ))}
                    </div>
                    <button className="save-button">Save</button>
                </div>
            </div>
        </div>
    );
};

export default AccommodationPreferences;
